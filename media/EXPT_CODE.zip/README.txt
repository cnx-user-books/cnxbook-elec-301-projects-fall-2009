Table of Contents
-----------------
demo.m -- Test script.  Performs a single non-noise random knock-out trial and displays the reconstructed network.
expt1A.m -- Simulation code for random knock-out, no noise trials.
expt1B.m -- Simulation code for random knock-out, noise present trials.
expt2A.m -- Simulation code for realistic knock-out, no noise trials.
expt2B.m -- Simulation code for realistic knock-out, noise present trials.
reconstruction.m -- MDS routine for reconstructing a network from its distance matrix.
