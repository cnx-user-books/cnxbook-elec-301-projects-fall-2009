% Generate and plot N random points inside the unit square.
N = 200;
X = rand(2, N );

% Form Euclidean distance matrix.
D = zeros(N, N);
for (i = 1:1:N)
	for (j = 1:1:N)
		D(i, j) = norm(X(:, i) - X(:, j));
	end
end

% Plot the original sensor network.
figure(1);
Y1 = reconstruction(D);
plot(Y1(:, 1), Y1(:, 2), 'b.');

% Convert to squares-of-distances matrix.
D2 = D.^2;

% Replace all zero entries (the ones on the diagonal) with epsilon.
% This is necessary because OptSpace takes zero entries to be unknown, and
% we know that the diagonal entries should be zero to begin with.
for (i = 1:1:N)
	D2(i, i) = eps;
end

% Knock out a few entries.  (Remember that we know every entry on the
% diagonal and that if we don't know entry ij, we don't know entry ji
% either.)
R = D2;

for (i = 1:1:N)
	for (j = 1:1:(i - 1))
		r = rand;
		if (r < 0.90)
			R(i, j) = 0;
			R(j, i) = 0;
		end
	end
end

% Complete the matrix.  We know that it will be rank-4.
[U, S, V, dist] = OptSpace(R, 4, 50, 1e-6);
D2_hat = U*S*V';

% Display the reconstruction of the network.  Note that MDS is only
% unique up to a rigid transformation, so some adjustments may be necessary
% to see the best possible fit.
Y2 = reconstruction(sqrt(D2_hat));

figure(2);
plot(Y1(:, 1), Y1(:, 2), 'b.', Y2(:, 1), Y2(:, 2), 'r.');
