% expt2B.m -- Realistically eliminate distance pairs with noise.
%             Performs 25 trials and reports average normalized Frobenius 
%             norm error.
%
%

% Number of trials.
T = 25;
alpha = [0.01 0.05 0.1 0.2 0.5];

% Vector to hold Frobenius-norm errors for each maximum radius.
rmax = 0.1:0.01:1;
e = zeros(length(rmax), length(alpha));    % Errors for non-squared distance matrix.
e2 = zeros(length(rmax), length(alpha));   % Errors for squared distance matrix.
entryfrac = zeros(length(rmax), length(alpha));  % Store average fraction of known entries.

% Do for all probabilities.
for (n = 1:1:length(rmax))
    % Do for all noise amplitudes.
    for (m = 1:1:length(alpha))
        % Do T trials.
        for (k = 1:1:T)       
            % Generate N random points inside the unit square.
            N = 200;
            X = rand(2, N);

            % Form Euclidean distance matrix.
            D = zeros(N, N);
            for (i = 1:1:N)
                for (j = 1:1:N)
                    D(i, j) = norm(X(:, i) - X(:, j));
                end
            end

            % Add some white noise.
            D_noise = D + alpha(m)*randn(N, N);
            
            % Convert to squares-of-distances matrix.
            D2 = D.^2;
            D2_noise = D_noise.^2;            

            % Replace all zero entries (the ones on the diagonal) with epsilon.
            for (i = 1:1:N)
                D2_noise(i, i) = eps;
            end

            % Knock out off-diagonal entries with distance larger than r_max.
            R = D2_noise;

            for (i = 1:1:N)
                for (j = 1:1:N)
                    if (D(i, j) > rmax(n))
                        R(i, j) = 0;
                    end
                end
            end
            
            % Store fraction of known entries.
            entryfrac(n) = entryfrac(n) + (nnz(R) / (N * N));

            % Complete the matrix.  We know that it will be rank-4.
            [U, S, V, dist] = OptSpace(R, 4, 50, 1e-6);
            D2_hat = U*S*V';

            % Compute and store normalized Frobenius norm error for both
            % matrices.
            e(n, m) = e(n, m) + norm(D - sqrt(D2_hat), 'fro') / norm(D, 'fro');
            e2(n, m) = e(n, m) + norm(D2 - D2_hat, 'fro') / norm(D2, 'fro');
        end

        % Average over T trials.
        e(n, m) = e(n, m) / T;
        e2(n, m) = e2(n, m) / T;
        entryfrac(n, m) = entryfrac(n, m) / T;
        
        % Print something to make sure we're alive.
        disp(['m = ' num2str(n)]);
    end
    
    % Print something to make sure that we're alive.
    disp(['n = ' num2str(n)]);
end

% Plot error versus probability.
plot(rmax, e, 'b.');
title('Experiment 2B:  Average Frobenius Norm Error vs.  Maximum Radius');
xlabel('Maximum Radius');
ylabel('Average Frobenius Norm Error (Normalized)');

% Save rmax and e vectors to file.
OUTPUT_FILE = 'EXPT2B.DAT';
FOUT = fopen(OUTPUT_FILE, 'wt');
for (i = 1:1:length(rmax))
    fprintf(FOUT, '%f ', rmax(i));
end
fprintf(FOUT, '\n\n');
for (i = 1:1:length(rmax))
    for (j = 1:1:length(alpha))
        fprintf(FOUT, '%f ', e(i, j));
    end
    fprintf(FOUT, '\n');
end
fprintf(FOUT, '\n\n');
for (i = 1:1:length(rmax))
    for (j = 1:1:length(alpha))
        fprintf(FOUT, '%f ', e2(i, j));
    end
    fprintf(FOUT, '\n');
end
fprintf(FOUT, '\n\n');
for (i = 1:1:length(rmax))
    for (j = 1:1:length(alpha))
        fprintf(FOUT, '%f ', entryfrac(i, j));
    end
    fprintf(FOUT, '\n');
end