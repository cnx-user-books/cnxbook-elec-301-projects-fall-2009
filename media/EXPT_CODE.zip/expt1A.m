% expt1A.m -- Randomly eliminate distance pairs without noise.
%             Performs 25 trials and reports average normalized Frobenius
%             norm error.
%
%

% Number of trials.
T = 25;

% Vector to store simulation parameters.
p = 0:0.01:0.95;
e = zeros(length(p), 1);    % Errors for non-squared distance matrix.
e2 = zeros(length(p), 1);   % Errors for squared distance matrix.

% Do for all probabilities.
for (n = 1:1:length(p))
    % Do T trials.
    for (k = 1:1:T)       
        % Generate N random points inside the unit square.
        N = 200;
        X = rand(2, N);
        
        % Form Euclidean distance matrix.
        D = zeros(N, N);
        for (i = 1:1:N)
            for (j = 1:1:N)
                D(i, j) = norm(X(:, i) - X(:, j));
            end
        end

        % Convert to squares-of-distances matrix.
        D2 = D.^2;

        % Replace all zero entries (the ones on the diagonal) with epsilon.
        for (i = 1:1:N)
            D2(i, i) = eps;
        end

        % Knock out a few entries.  (Remember that we know every entry on the
        % diagonal and that if we don't know entry ij, we don't know entry ji
        % either.)
        R = D2;

        for (i = 1:1:N)
            for (j = 1:1:(i - 1))
                r = rand;
                if (r < p(n))
                    R(i, j) = 0;
                    R(j, i) = 0;
                end
            end
        end

        % Complete the matrix.  We know that it will be rank-4.
        [U, S, V, dist] = OptSpace(R, 4, 50, 1e-6);
        D2_hat = U*S*V';
        
        % Compute and store normalized Frobenius norm error for both
        % matrices.
        e(n) = e(n) + norm(D - sqrt(D2_hat), 'fro') / norm(D, 'fro');
        e2(n) = e(n) + norm(D2 - D2_hat, 'fro') / norm(D2, 'fro');
    end
    
    % Average over T trials.
    e(n) = e(n) / T;
    e2(n) = e2(n) / T;
    
    % Print something to show that we're alive.
    disp(num2str(n));
end

% Plot error versus probability.
plot(p, e, 'b.');
title('Experiment 1A:  Average Frobenius Norm Error vs.  Fraction of Unknown Distances');
xlabel('Fraction of Unknown Distances');
ylabel('Average Frobenius Norm Error (Normalized)');

% Save data to file.
OUTPUT_FILE = 'EXPT1A.DAT';
FOUT = fopen(OUTPUT_FILE, 'wt');
for (i = 1:1:length(p))
    fprintf(FOUT, '%f ', p(i));
end
fprintf(FOUT, '\n\n');
for (i = 1:1:length(e))
    fprintf(FOUT, '%f ', e(i));
end
fprintf(FOUT, '\n\n');
for (i = 1:1:length(e2))
    fprintf(FOUT, '%f ', e2(i));
end