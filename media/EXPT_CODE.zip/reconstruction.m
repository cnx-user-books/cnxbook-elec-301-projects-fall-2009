%input a matrix D which contains relative distances. Each row of D
%corresponds to one unit, and the columns represent the relative distances.
%For example, D(1,1) represents the distance of the first unit from the
%first unit (0), and D(1,2) represents the distance of the first unit from
%the second unit.

function X=reconstruction(D)

%step 1 in the algorithm is to obtain the square of the relative distance
%matrix
Dsquare=D.^2;
%step 2 involves double centering
for i=1:length(D)
    B(i,:)=Dsquare(i,:)-mean(mean(Dsquare(i,:))); %subtract the row means
end
for j=1:length(D)
    B(:,j)=B(:,j)-mean(mean(B(:,j))); %subtract the column means
end
B=B+mean(mean(B)); %add the grand mean
B=B*-.5; %multiply by -1/2
%step 3 is the eigendecomposition of the B matrix 
[u,v]=eig(B);

v2=eig(B);
%we are only interested in positive eigenvalues and can knock out any zero
%or negative ones.
a=find(v2>.001); 
%matlab makes errors--this is a decent threshold to account for that
%potential error
Qused=zeros(length(D),1);
%finding the columns of Q that we need from the QVQ decomposition
for i=1:length(a)
    if i==1
    Qused=[u(:,a(i))];
    else
        Qused=[Qused u(:,a(i))];
    end
end
[r,c]=size(Qused);
vused=0;
%constructing the matrix of useful eigenvalues
for f=1:c
    if f==1
    vused=[zeros(1,f-1) v2(a(f)) zeros(1,c-f)];
    else
        vused=[vused;zeros(1,f-1) v2(a(f)) zeros(1,c-f)]; 
    end
   
end
%computing the final coordinate matrix X
X=Qused*sqrt(vused);

